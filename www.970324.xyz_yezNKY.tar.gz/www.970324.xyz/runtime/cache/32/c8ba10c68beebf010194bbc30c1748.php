<?php
//000000003600
 exit();?>
a:14:{s:7:"vod_all";i:1;s:7:"vod_min";d:1;s:7:"art_min";d:0;s:10:"type_all_6";i:1;s:10:"type_all_1";i:1;s:9:"topic_all";i:0;s:11:"topic_today";i:0;s:9:"tpoic_min";d:0;s:9:"actor_all";i:0;s:11:"actor_today";i:0;s:9:"actor_min";d:0;s:8:"role_all";i:0;s:10:"role_today";i:0;s:8:"role_min";d:0;}